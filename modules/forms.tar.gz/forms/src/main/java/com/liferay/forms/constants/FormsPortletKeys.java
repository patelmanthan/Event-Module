package com.liferay.forms.constants;

/**
 * @author manthan
 */
public class FormsPortletKeys {

	public static final String Forms = "Custom-Forms";

}